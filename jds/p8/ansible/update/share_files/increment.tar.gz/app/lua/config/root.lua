local hello = {}

function hello.say()
    return "Hello, World!"
end

return hello
